# ender-ansi
simple python script for ANSI escape codes
